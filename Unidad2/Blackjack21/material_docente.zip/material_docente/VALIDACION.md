# Validación del paquete Blackjack 21

**Fecha:** 5 de octubre de 2026.  
**Entorno verificado:** Ubuntu, Python 3.12.3.  
**Dependencias del juego y de las pruebas:** biblioteca estándar de Python.

## Resultado funcional

Se ejecutaron **51 pruebas automáticas**, sin errores ni fallos. Una de ellas simula **5,000 rondas** con reparto mezclado y selección de acciones legales mediante una semilla fija (`20261005`).

Para repetir la batería desde `Blackjack21/`:

```bash
python3 -m unittest discover -s material_docente -v
```

Resultado esperado para el paquete entregado:

```text
Ran 51 tests
OK
```

## Comportamientos comprobados

| Área | Comprobación realizada |
| --- | --- |
| Zapato | 312 cartas; 52 combinaciones de rango y palo; seis copias por combinación; cada reparto extrae una carta. |
| Rebarajado | Se renueva entre rondas cuando quedan 110 cartas o menos; no se reemplazan cartas durante la ronda. |
| Puntuación | Figuras, varios ases, transición entre mano suave y dura y reconocimiento del natural con dos cartas. |
| Entradas | Nombre vacío, respuestas sí/no, apuestas inválidas, decimales, falta de saldo y acciones fuera del menú. |
| Información visible | La carta tapada y el total completo del crupier no aparecen antes de revelarlo; los datos se dividen por renglones y cada interacción comienza con un separador. |
| Jugador | Pedir, llegar a 21, pasarse, plantarse y terminar el turno. |
| Doblar | Cobra otra apuesta igual, recibe una carta y termina la mano; casos de victoria y derrota. |
| Separar | Pares del mismo valor, orden de reparto, avance de manos, hasta cuatro manos y doblar después de separar. |
| Ases separados | Una carta adicional por mano, cierre automático y 21 sin pago de blackjack natural. |
| Rendición | Recupera la mitad; no obliga al crupier a pedir si ya no quedan manos por comparar. |
| Crupier | Pide con 16, se planta con 17 duro o suave, no pide si todas las manos se pasaron o se rindieron y espera 1.0 segundo después de cada carta mostrada. |
| Pagos | Victoria, derrota, empate, dos naturales, natural frente a 21 ordinario y apuestas impares con medias fichas. |
| Seguro | Ganado, perdido, rechazado, falta de saldo y apuesta independiente de la mano principal. |
| Liquidación | Actualiza el saldo y las estadísticas por mano; impide pagar dos veces la misma ronda. |
| Sesión completa | Salida voluntaria, dos rondas seguidas, natural sin menús, seguro, separación y fin por saldo insuficiente. |
| Práctica/solución | Igualdad del árbol de código fuera de `init()`; tres `while` en la solución y plantilla pendiente en la práctica. |
| Simulación | 5,000 rondas legales sin saldo negativo, más de cuatro manos, agotamiento del zapato o ciclos sin terminar. |

## Alcance

Además se ejecutó una partida completa de la solución por terminal con entrada estándar y salida voluntaria. La práctica sin completar mostró su aviso y terminó correctamente. Se comprobó que todos los enlaces locales del Markdown existen, que el bloque Mermaid coincide con su archivo independiente y que el texto de ambos juegos fuera de `init()` es idéntico. El SVG se renderizó y se revisó visualmente.

Las pruebas comprueban la solución de referencia y las funciones compartidas. No sustituyen la revisión de la explicación del estudiante ni califican su `init()` una vez que modifica la plantilla. La simulación revisa estabilidad funcional; no calcula probabilidades ni certifica una estrategia de juego.

La batería se conserva en `material_docente/test_blackjack21.py` para hacer las comprobaciones reproducibles. El README incluye los casos que pueden revisar los estudiantes jugando.
