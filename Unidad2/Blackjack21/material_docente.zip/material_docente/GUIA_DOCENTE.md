# Guía para impartir Blackjack 21 con `while`

## Propósito y materiales

El juego parte de `BlackJack21.py`, elaborado por Carlos Gabriel Rodríguez Macías como uno de sus primeros programas en Python. La versión educativa conserva las apuestas ficticias y las seis barajas, organiza las funciones y corrige puntuación, turno del crupier y pagos. La complejidad de las reglas queda dentro de las funciones ya preparadas.

La tarea del estudiante es completar **solo `init()`**. La solución de referencia organiza tres ciclos: rondas, acciones del jugador y reparto del crupier. Las demás funciones son iguales en los dos archivos del juego.

Para compartir la actividad con el grupo, entrega:

- `blackjack21_practica.py`.
- `README.md`.
- La carpeta `diagramas/` junto al Markdown, para conservar sus imágenes y enlaces al diagrama.

La solución, las pruebas y esta guía se conservan juntas en `material_docente/`. La carpeta completa está excluida mediante `.gitignore`, por lo que el repositorio para estudiantes no publica estos archivos.

## Sesión sugerida: 60 a 80 minutos

| Tiempo | Actividad | Qué conviene observar |
| --- | --- | --- |
| 10 min | Mostrar una ronda en la versión resuelta; explicar pedir y plantarse. | Distinguir una acción, un turno y una ronda. |
| 10 min | Leer el diagrama e identificar sus tres regresos. | Decir en voz alta cuándo se deja de repetir cada proceso. |
| 10 min | Revisar la tabla de funciones y el ejemplo de `while`. | Distinguir funciones que actúan de funciones que devuelven una condición o un dato. |
| 20–30 min | Completar `init()` en parejas o individualmente. | Ubicar los dos turnos dentro de cada ronda y uno después del otro. |
| 10–20 min | Probar continuación, salida e instrucciones inválidas; responder reflexiones. | Cambiar la bandera y liquidar exactamente una vez por ronda. |

Una primera demostración puede usar solo pedir y plantarse. Después presenta doblar y separar para mostrar que el mismo ciclo de acciones sigue funcionando: la función cambia el estado y el `while` vuelve a consultar la condición. Los estudiantes no tienen que programar estas reglas.

## Qué pedir antes de que escriban código

Pide que señalen en el diagrama:

1. Las operaciones que ocurren una vez por sesión: creación, bienvenida y despedida.
2. Las operaciones que ocurren una vez por ronda: apuesta, reparto y liquidación.
3. Las operaciones que ocurren varias veces durante un turno: preguntar/aplicar o repartir al crupier.
4. El camino del blackjack inicial, que omite los dos turnos.
5. La instrucción que cambia la bandera cuando el jugador quiere terminar.

No hace falta explicar todo el motor de cartas para empezar. Las funciones se presentan como contratos: qué reciben, qué devuelven y qué cambian. El código interno queda disponible para estudiantes que quieran explorar listas, tuplas y diccionarios después.

## Criterios de evaluación sugeridos

| Criterio | Puntos |
| --- | ---: |
| Crea la sesión una sola vez, saluda e inicializa la bandera. | 10 |
| El `while` principal requiere querer continuar y poder apostar. | 20 |
| Prepara cada ronda y maneja el blackjack inicial sin ejecutar turnos adicionales. | 15 |
| El ciclo del jugador pregunta y aplica una acción nueva por vuelta. | 20 |
| El ciclo del crupier sigue su condición y reparte una carta por vuelta. | 15 |
| Liquida una vez por ronda, actualiza la bandera y despide fuera del ciclo. | 15 |
| Explica las condiciones de salida y conserva las funciones de apoyo. | 5 |
| **Total** | **100** |

Se pueden aceptar nombres de variables diferentes y alternativas de organización que mantengan el comportamiento y demuestren `while`. Evalúa el control de flujo y la explicación del estudiante; el objetivo no es copiar literalmente la solución.

## Comprobaciones y límites

Desde la carpeta `Blackjack21/`:

```bash
python3 -m unittest discover -s material_docente -v
```

Las 51 pruebas validan la **solución de referencia**, sus reglas, los colores/emojis y la igualdad de las funciones de apoyo. Una de ellas simula 5,000 rondas con una semilla fija. No califican automáticamente el `init()` que entregue un estudiante. La plantilla debe estar sin resolver para que la prueba de distribución del paquete pase.

Después de que un estudiante complete su práctica, evalúa su archivo mediante ejecución y revisión del flujo. La comprobación que exige una plantilla pendiente dejará de cumplirse en esa copia; eso no significa que su solución sea incorrecta.

Las cartas de las partidas normales son aleatorias. La batería automática controla el reparto para probar casos como dos blackjack, separación de ases o quedarse sin saldo. Las instrucciones inválidas vuelven a preguntarse sin descontar fichas.

## Reglas elegidas y explicación de los cambios

- **Cartas:** seis copias de una baraja con cuatro palos; se sacan sin reposición durante el zapato. Se rebaraja entre rondas con una reserva conservadora de 110 cartas.
- **Ases:** la puntuación usa el mejor total válido sin convertir números en textos con barras.
- **Crupier:** sigue S17; no decide pedir simplemente para superar el total del jugador.
- **Naturales:** se resuelven antes de los turnos. Dos naturales empatan; un 21 con más cartas o después de separar no recibe el premio especial.
- **Pagos:** se distingue apuesta devuelta, ganancia y balance. El blackjack paga 3:2. Las centésimas evitan errores con seguros y apuestas impares.
- **Opciones:** doblar, separar hasta cuatro manos, seguro de media apuesta y rendición tardía en la mano original. Los ases separados reciben una carta y terminan.
- **Experiencia:** carta oculta sin revelar su total; símbolos de palos alineados y coloreados; información dividida por renglones; separadores entre interacciones; pausa de un segundo por carta del crupier; colores ANSI sin dependencias; menús de acciones legales; salida entre rondas; resumen de saldo y estadísticas por mano.

Estas decisiones están detalladas en el README. El juego es una mesa educativa de un jugador contra el crupier. El saldo no se guarda al cerrar; no contiene pagos ni apuestas reales.
