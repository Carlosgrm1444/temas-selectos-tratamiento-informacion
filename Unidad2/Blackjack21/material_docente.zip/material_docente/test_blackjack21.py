"""Comprobaciones funcionales del paquete educativo; no necesita dependencias."""
import ast
import contextlib
import copy
import importlib.util
import io
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
CARPETA_PROYECTO = Path(__file__).resolve().parents[1]
CARPETA_DOCENTE = Path(__file__).resolve().parent
ESPEC = importlib.util.spec_from_file_location('bj', CARPETA_DOCENTE / 'blackjack21_resuelto.py')
bj = importlib.util.module_from_spec(ESPEC)
ESPEC.loader.exec_module(bj)


def cartas(*rangos):
    return [(str(rango), 'Picas') for rango in rangos]


def juego_ronda(jugador, crupier, apuesta=5000, extras=(), saldo=200000):
    with patch('builtins.input', return_value='Prueba'):
        juego = bj.crear_juego()
    juego.update({
        'saldo': saldo - apuesta,
        'saldo_inicio_ronda': saldo,
        'manos': [bj.nueva_mano(cartas(*jugador), apuesta)],
        'crupier': cartas(*crupier),
        'mazo': list(reversed(cartas(*extras))),
        'ronda': 1,
        'liquidada': False,
    })
    return juego


class BlackjackTests(unittest.TestCase):
    def setUp(self):
        self.salida = io.StringIO()
        self.redirect = contextlib.redirect_stdout(self.salida)
        self.redirect.__enter__()

    def tearDown(self):
        self.redirect.__exit__(None, None, None)

    def test_cartas_reales_312_seis_copias(self):
        mazo = bj.barajear()
        self.assertEqual(len(mazo), 312)
        self.assertEqual(len(set(mazo)), 52)
        self.assertTrue(all(mazo.count(carta) == 6 for carta in set(mazo)))

    def test_extraer_no_reponer(self):
        juego = {'mazo': cartas('A', 'K')}
        mano = []
        bj.dar_carta(juego, mano)
        self.assertEqual(mano, cartas('K'))
        self.assertEqual(juego['mazo'], cartas('A'))

    def test_no_rebaraja_al_agotarse_en_ronda(self):
        with self.assertRaises(RuntimeError):
            bj.dar_carta({'mazo': []}, [])

    def test_ases_figuras_totales(self):
        ejemplos = [([], 0), (['A'], 11), (['A', '6'], 17),
                    (['A', '6', '10'], 17), (['A', 'A', '9'], 21),
                    (['A', 'A', 'A', '8'], 21), (['A', 'A', 'K'], 12),
                    (['A', 'K'], 21), (['J', 'Q', 'K'], 30)]
        for mano, esperado in ejemplos:
            with self.subTest(mano=mano):
                self.assertEqual(bj.calcular_total(cartas(*mano)), esperado)

    def test_suave_y_dura(self):
        self.assertTrue(bj.es_mano_suave(cartas('A', '6')))
        self.assertFalse(bj.es_mano_suave(cartas('A', '6', '10')))
        self.assertFalse(bj.es_mano_suave(cartas('10', '7')))

    def test_blackjack_solo_dos_cartas(self):
        self.assertTrue(bj.es_blackjack(cartas('A', 'K')))
        self.assertFalse(bj.es_blackjack(cartas('7', '7', '7')))

    def test_formato_centavos_y_negativos(self):
        for valor, texto in [(200000, '2000.00'), (12750, '127.50'),
                             (0, '0.00'), (-2550, '-25.50'), (1, '0.01')]:
            with self.subTest(valor=valor):
                self.assertEqual(bj.dinero(valor), texto)

    def test_colores_ansi_y_emojis_de_palos(self):
        self.assertEqual(set(bj.SIMBOLOS.values()), {'♠', '♥', '♦', '♣'})
        with patch.object(bj, 'USAR_COLORES', True):
            self.assertEqual(bj.pintar('Ganaste', bj.NEGRITA, bj.VERDE),
                             '\033[1m\033[92mGanaste\033[0m')
        with patch.object(bj, 'USAR_COLORES', False):
            self.assertEqual(bj.pintar('Ganaste', bj.NEGRITA, bj.VERDE), 'Ganaste')
        bj.dibujar_cartas([('A', 'Corazones'), ('10', 'Picas')])
        lineas = self.salida.getvalue().splitlines()
        self.assertTrue(all(len(linea) == 19 for linea in lineas[-5:]))

    def test_nombre_por_defecto_y_estado_independiente(self):
        with patch('builtins.input', return_value='  '):
            uno = bj.crear_juego()
            dos = bj.crear_juego()
        self.assertEqual(uno['nombre'], 'Jugador')
        uno['mazo'].append(('A', 'Picas'))
        self.assertEqual(dos['mazo'], [])

    def test_si_no_y_opciones_invalidas(self):
        with patch('builtins.input', side_effect=['talvez', ' SÍ ']) as entrada:
            self.assertTrue(bj.preguntar_si_no('Continuar'))
        self.assertEqual(entrada.call_count, 2)
        with patch('builtins.input', return_value='NO'):
            self.assertFalse(bj.preguntar_si_no('Continuar'))

    def test_apuestas_invalidas_reintenta_y_no_descuenta(self):
        juego = {'saldo': 5000}
        with patch('builtins.input', side_effect=['', 'abc', '50.5', '-1', '0', '49', '51', '50']):
            self.assertEqual(bj.pedir_apuesta(juego), 5000)
        self.assertEqual(juego['saldo'], 5000)

    def test_preparar_alterna_y_descuenta_una_vez(self):
        with patch('builtins.input', return_value='Ana'):
            juego = bj.crear_juego()
        mazo = cartas(*(['2'] * 120)) + list(reversed(cartas('8', '6', '9', '10')))
        with patch.object(bj, 'barajear', return_value=mazo), patch('builtins.input', return_value='51'):
            bj.preparar_ronda(juego)
        self.assertEqual(juego['manos'][0]['cartas'], cartas('8', '9'))
        self.assertEqual(juego['crupier'], cartas('6', '10'))
        self.assertEqual(juego['saldo'], 194900)
        self.assertEqual(len(juego['mazo']), 120)
        self.assertFalse(juego['liquidada'])
        self.assertFalse(juego['crupier_visible'])

    def test_reserva_rebaraja_solo_entre_rondas(self):
        for restantes, esperado in [(110, 1), (111, 0)]:
            with self.subTest(restantes=restantes):
                with patch('builtins.input', return_value='Ana'):
                    juego = bj.crear_juego()
                juego['mazo'] = cartas(*(['2'] * restantes))
                with patch.object(bj, 'barajear', return_value=cartas(*(['3'] * 312))) as mezcla:
                    with patch('builtins.input', return_value='50'):
                        bj.preparar_ronda(juego)
                self.assertEqual(mezcla.call_count, esperado)

    def test_preparar_protege_ronda_y_saldo(self):
        juego = juego_ronda(['10', '8'], ['10', '7'])
        with self.assertRaises(RuntimeError):
            bj.preparar_ronda(juego)
        juego['liquidada'] = True
        juego['saldo'] = 4999
        with self.assertRaises(RuntimeError):
            bj.preparar_ronda(juego)

    def test_mesa_no_filtra_carta_oculta_ni_total(self):
        juego = juego_ronda(['10', '8'], ['6', 'K'])
        bj.mostrar_mesa(juego)
        salida = self.salida.getvalue()
        self.assertIn('-' * bj.ANCHO_SEPARADOR, salida)
        self.assertIn('Carta visible: 6', salida)
        self.assertIn('Total: oculto', salida)
        self.assertIn('JUGADOR: Prueba', salida)
        self.assertIn('Mano: 1', salida)
        self.assertIn('Apuesta: 50.00 fichas', salida)
        self.assertNotIn('Total: 16', salida)
        self.assertNotIn('│K', salida)
        self.assertIn('░░░░░░░', salida)

    def test_revelar_muestra_total_y_carta(self):
        juego = juego_ronda(['10', '8'], ['6', 'K'])
        bj.revelar_crupier(juego)
        self.assertTrue(juego['crupier_visible'])
        self.assertIn('CRUPIER', self.salida.getvalue())
        self.assertIn('Total: 16', self.salida.getvalue())
        self.assertIn('│K', self.salida.getvalue())

    def test_menu_oculta_acciones_sin_saldo(self):
        juego = juego_ronda(['8', '8'], ['10', '7'], saldo=5000)
        self.assertEqual(set(bj.acciones_disponibles(juego)), {'1', '2', '5'})

    def test_accion_ilegal_no_muta(self):
        juego = juego_ronda(['8', '8'], ['10', '7'], saldo=5000)
        antes = copy.deepcopy(juego)
        with self.assertRaises(ValueError):
            bj.aplicar_accion(juego, '3')
        self.assertEqual(juego, antes)

    def test_menu_rechaza_accion_no_disponible(self):
        juego = juego_ronda(['10', '5', '2'], ['10', '7'])
        with patch('builtins.input', side_effect=['3', '4', '5', '2']):
            self.assertEqual(bj.preguntar_accion(juego), '2')

    def test_pedir_21_cierra_turno(self):
        juego = juego_ronda(['10', '5'], ['10', '7'], extras=['6'])
        bj.aplicar_accion(juego, '1')
        self.assertFalse(bj.hay_turno_jugador(juego))
        self.assertFalse(bj.es_blackjack(juego['manos'][0]['cartas']))

    def test_pedir_pasarse_cierra_turno(self):
        juego = juego_ronda(['10', '8'], ['10', '7'], extras=['5'])
        bj.aplicar_accion(juego, '1')
        self.assertFalse(bj.hay_turno_jugador(juego))
        self.assertFalse(bj.debe_pedir_crupier(juego))

    def test_pedir_normal_continua_y_oculta_doblar(self):
        juego = juego_ronda(['2', '3'], ['10', '7'], extras=['4'])
        bj.aplicar_accion(juego, '1')
        self.assertTrue(bj.hay_turno_jugador(juego))
        self.assertEqual(set(bj.acciones_disponibles(juego)), {'1', '2'})

    def test_plantarse_cierra_turno(self):
        juego = juego_ronda(['10', '8'], ['10', '7'])
        bj.aplicar_accion(juego, '2')
        self.assertFalse(bj.hay_turno_jugador(juego))

    def test_doblar_una_carta_cobra_y_cierra(self):
        juego = juego_ronda(['5', '6'], ['10', '7'], extras=['10', '2'])
        bj.aplicar_accion(juego, '3')
        self.assertEqual(juego['saldo'], 190000)
        self.assertEqual(juego['manos'][0]['apuesta'], 10000)
        self.assertEqual(len(juego['manos'][0]['cartas']), 3)
        self.assertEqual(len(juego['mazo']), 1)
        self.assertFalse(bj.hay_turno_jugador(juego))
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 210000)

    def test_doblar_y_perder(self):
        juego = juego_ronda(['10', '6'], ['10', '7'], extras=['10'])
        bj.aplicar_accion(juego, '3')
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 190000)

    def test_separar_reparte_segunda_mano_al_llegar_su_turno(self):
        juego = juego_ronda(['8', '8'], ['10', '7'], extras=['2', '3', '4'])
        bj.aplicar_accion(juego, '4')
        self.assertEqual(len(juego['manos']), 2)
        self.assertEqual(juego['saldo'], 190000)
        self.assertEqual(juego['manos'][0]['cartas'], cartas('8', '2'))
        self.assertEqual(juego['manos'][1]['cartas'], cartas('8'))
        bj.aplicar_accion(juego, '1')
        bj.aplicar_accion(juego, '2')
        self.assertEqual(juego['indice_mano'], 1)
        self.assertEqual(juego['manos'][1]['cartas'], cartas('8', '4'))

    def test_separar_valor_10_figuras_distintas(self):
        juego = juego_ronda(['J', 'K'], ['10', '7'], extras=['2', '3'])
        self.assertIn('4', bj.acciones_disponibles(juego))
        bj.aplicar_accion(juego, '4')
        self.assertEqual(len(juego['manos']), 2)

    def test_reseparar_hasta_cuatro_sin_mas(self):
        juego = juego_ronda(['8', '8'], ['10', '7'], extras=['8', '8', '8'])
        for _ in range(3):
            bj.aplicar_accion(juego, '4')
        self.assertEqual(len(juego['manos']), 4)
        self.assertNotIn('4', bj.acciones_disponibles(juego))
        self.assertEqual(juego['saldo'], 180000)

    def test_ases_separados_una_carta_y_sin_blackjack(self):
        juego = juego_ronda(['A', 'A'], ['10', '7'], extras=['K', 'A'])
        bj.aplicar_accion(juego, '4')
        self.assertFalse(bj.hay_turno_jugador(juego))
        self.assertEqual(juego['manos'][0]['cartas'], cartas('A', 'K'))
        self.assertEqual(juego['manos'][1]['cartas'], cartas('A', 'A'))
        self.assertEqual(bj.resultado_mano(juego['manos'][0], juego['crupier']), ('victoria', 10000))

    def test_doblar_despues_de_separar_y_no_rendicion(self):
        juego = juego_ronda(['8', '8'], ['10', '7'], extras=['3', '10', '2'])
        bj.aplicar_accion(juego, '4')
        self.assertIn('3', bj.acciones_disponibles(juego))
        self.assertNotIn('5', bj.acciones_disponibles(juego))
        bj.aplicar_accion(juego, '3')
        self.assertEqual(juego['manos'][0]['apuesta'], 10000)
        self.assertEqual(juego['indice_mano'], 1)

    def test_rendicion_media_apuesta_impar(self):
        juego = juego_ronda(['10', '6'], ['10', '7'], apuesta=5100)
        bj.aplicar_accion(juego, '5')
        self.assertFalse(bj.debe_pedir_crupier(juego))
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 197450)

    def test_crupier_16_17_suave_y_fijo(self):
        for crupier, jugador, esperado in [(['10', '6'], ['2', '3'], True),
                                            (['10', '7'], ['10', '9'], False),
                                            (['A', '6'], ['10', '9'], False),
                                            (['A', '5'], ['10', '9'], True),
                                            (['10', 'K', '3'], ['10', '9'], False)]:
            with self.subTest(crupier=crupier):
                self.assertEqual(bj.debe_pedir_crupier(juego_ronda(jugador, crupier)), esperado)

    def test_crupier_no_pide_si_todas_perdidas_o_rendidas(self):
        juego = juego_ronda(['10', 'K', '3'], ['2', '3'])
        juego['manos'].append(bj.nueva_mano(cartas('10', '6'), 5000, True))
        juego['manos'][1]['rendida'] = True
        self.assertFalse(bj.debe_pedir_crupier(juego))

    def test_crupier_pide_si_queda_una_mano_viva(self):
        juego = juego_ronda(['10', 'K', '3'], ['2', '3'], extras=['10'])
        juego['manos'].append(bj.nueva_mano(cartas('10', '6'), 5000, True))
        self.assertTrue(bj.debe_pedir_crupier(juego))
        bj.dar_carta_crupier(juego)
        self.assertEqual(bj.calcular_total(juego['crupier']), 15)
        with patch.object(bj.time, 'sleep') as espera:
            bj.pausar_crupier()
        espera.assert_called_once_with(1.0)

    def test_resultados_prioridades_y_pagos(self):
        casos = [(['10', '8'], ['10', '7'], False, ('victoria', 10000)),
                 (['10', '7'], ['10', '8'], False, ('derrota', 0)),
                 (['10', '8'], ['10', '8'], False, ('empate', 5000)),
                 (['10', '5'], ['10', '6', '10'], False, ('victoria', 10000)),
                 (['10', '6', '10'], ['10', '6', '10'], False, ('derrota', 0)),
                 (['A', 'K'], ['A', 'Q'], False, ('empate', 5000)),
                 (['7', '7', '7'], ['A', 'Q'], False, ('derrota', 0)),
                 (['A', 'K'], ['7', '7', '7'], False, ('blackjack', 12500)),
                 (['A', 'K'], ['10', '9'], True, ('victoria', 10000)),
                 (['A', 'K'], ['A', 'Q'], True, ('derrota', 0))]
        for jugador, crupier, separada, esperado in casos:
            with self.subTest(jugador=jugador, crupier=crupier, separada=separada):
                mano = bj.nueva_mano(cartas(*jugador), 5000, separada)
                self.assertEqual(bj.resultado_mano(mano, cartas(*crupier)), esperado)

    def test_natural_apuesta_51_pago_exacto(self):
        juego = juego_ronda(['A', 'K'], ['10', '7'], apuesta=5100)
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 207650)

    def test_seguro_ganado_independiente_de_mano(self):
        juego = juego_ronda(['10', '8'], ['A', 'K'], apuesta=5100)
        with patch('builtins.input', return_value='s'):
            bj.ofrecer_seguro(juego)
        self.assertEqual(juego['seguro'], 2550)
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 200000)

    def test_seguro_perdido_y_natural_ganado(self):
        juego = juego_ronda(['A', 'K'], ['A', '8'])
        with patch('builtins.input', return_value='s'):
            bj.ofrecer_seguro(juego)
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 205000)

    def test_seguro_dos_blackjack(self):
        juego = juego_ronda(['A', 'K'], ['A', 'Q'])
        with patch('builtins.input', return_value='s'):
            bj.ofrecer_seguro(juego)
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], 205000)

    def test_seguro_no_as_sin_saldo_o_rechazado(self):
        for crupier, saldo in [(['10', '7'], 200000), (['A', '7'], 5000)]:
            with self.subTest(crupier=crupier, saldo=saldo):
                juego = juego_ronda(['10', '8'], crupier, saldo=saldo)
                with patch('builtins.input') as entrada:
                    bj.ofrecer_seguro(juego)
                entrada.assert_not_called()
                self.assertEqual(juego['seguro'], 0)
        juego = juego_ronda(['10', '8'], ['A', '7'])
        with patch('builtins.input', return_value='n'):
            bj.ofrecer_seguro(juego)
        self.assertEqual(juego['seguro'], 0)
        self.assertEqual(juego['saldo'], 195000)

    def test_liquidacion_protege_doble_pago(self):
        juego = juego_ronda(['10', '8'], ['10', '7'])
        bj.liquidar_ronda(juego)
        saldo = juego['saldo']
        with self.assertRaises(RuntimeError):
            bj.liquidar_ronda(juego)
        self.assertEqual(juego['saldo'], saldo)

    def test_estadisticas_por_mano(self):
        juego = juego_ronda(['10', '8'], ['10', '7'])
        juego['manos'] += [bj.nueva_mano(cartas('10', '7'), 5000, True),
                           bj.nueva_mano(cartas('10', '6'), 5000, True)]
        bj.liquidar_ronda(juego)
        self.assertEqual(juego['estadisticas'], {'ganadas': 1, 'empatadas': 1, 'perdidas': 1})

    def ejecutar_init(self, reparto, entradas):
        mazo = cartas(*(['2'] * 120)) + list(reversed(cartas(*reparto)))
        with patch.object(bj, 'barajear', return_value=mazo):
            with patch('builtins.input', side_effect=entradas):
                with patch.object(bj.time, 'sleep') as espera:
                    bj.init()
        self.pausas_init = espera.call_args_list
        return self.salida.getvalue()

    def test_init_empate_turnos_y_salida_voluntaria(self):
        salida = self.ejecutar_init(['10', '6', '8', '10', '2'], ['Ana', '50', '2', 'n'])
        self.assertIn('Saldo final: 2000.00', salida)
        self.assertIn('Rondas: 1', salida)
        self.assertEqual(salida.count('Carta visible:'), 1)
        self.assertEqual(salida.count('El crupier pide una carta.'), 1)
        self.assertEqual([llamada.args for llamada in self.pausas_init], [(1.0,), (1.0,)])

    def test_init_blackjack_omite_menus_y_turnos(self):
        salida = self.ejecutar_init(['A', '10', 'K', '7'], ['Ana', '51', 'n'])
        self.assertIn('Saldo final: 2076.50', salida)
        self.assertNotIn('1. Pedir carta', salida)
        self.assertNotIn('El crupier pide una carta.', salida)

    def test_init_blackjack_crupier_y_seguro(self):
        salida = self.ejecutar_init(['10', 'A', '8', 'K'], ['Ana', '50', 's', 'n'])
        self.assertIn('Saldo final: 2000.00', salida)
        self.assertNotIn('1. Pedir carta', salida)

    def test_init_agota_saldo_y_no_pregunta_otra(self):
        salida = self.ejecutar_init(['10', '10', '8', '9'], ['Ana', '2000', '2'])
        self.assertIn('Saldo final: 0.00', salida)
        self.assertIn('ya no alcanza', salida)

    def test_init_dos_rondas_bandera_continua(self):
        reparto = ['10', '10', '8', '7', '10', '10', '8', '9']
        salida = self.ejecutar_init(reparto, ['Ana', '50', '2', 's', '50', '2', 'n'])
        self.assertIn('Rondas: 2', salida)
        self.assertIn('Saldo final: 2000.00', salida)

    def test_init_separacion_dos_manos_y_crupier(self):
        salida = self.ejecutar_init(['8', '10', '8', '7', '10', '9'], ['Ana', '50', '4', '2', '2', 'n'])
        self.assertIn('Mano 1: victoria', salida)
        self.assertIn('Mano 2: empate', salida)
        self.assertIn('Saldo final: 2050.00', salida)

    def test_plantilla_y_solucion_solo_difieren_init(self):
        arboles = []
        rutas = [
            CARPETA_PROYECTO / 'blackjack21_practica.py',
            CARPETA_DOCENTE / 'blackjack21_resuelto.py',
        ]
        for ruta in rutas:
            fuente = ruta.read_text()
            compile(fuente, ruta.name, 'exec')
            arbol = ast.parse(fuente)
            init = next(n for n in arbol.body if isinstance(n, ast.FunctionDef) and n.name == 'init')
            init.body = [ast.Pass()]
            arboles.append(ast.dump(arbol, include_attributes=False))
        self.assertEqual(*arboles)

    def test_init_tres_while_y_plantilla_sin_resolver(self):
        solucion = ast.parse((CARPETA_DOCENTE / 'blackjack21_resuelto.py').read_text())
        init = next(n for n in solucion.body if isinstance(n, ast.FunctionDef) and n.name == 'init')
        self.assertEqual(sum(isinstance(n, ast.While) for n in ast.walk(init)), 3)
        practica = ast.parse((CARPETA_PROYECTO / 'blackjack21_practica.py').read_text())
        init_p = next(n for n in practica.body if isinstance(n, ast.FunctionDef) and n.name == 'init')
        self.assertEqual(sum(isinstance(n, ast.While) for n in ast.walk(init_p)), 0)

    def test_simulacion_5000_rondas_legales(self):
        generador = random.Random(20261005)
        with patch('builtins.input', return_value='Simulador'):
            juego = bj.crear_juego()
        juego['saldo'] = 100000000
        with patch.object(bj.random, 'shuffle', side_effect=generador.shuffle):
            with patch('builtins.input', return_value='50'):
                for ronda in range(5000):
                    bj.preparar_ronda(juego)
                    # Recorre todas las opciones de forma determinista y legal.
                    if juego['crupier'][0][0] == 'A' and ronda % 2 == 0:
                        with patch('builtins.input', return_value='s'):
                            bj.ofrecer_seguro(juego)
                    if not bj.hay_blackjack_inicial(juego):
                        vueltas = 0
                        while bj.hay_turno_jugador(juego):
                            opciones = list(bj.acciones_disponibles(juego))
                            bj.aplicar_accion(juego, generador.choice(opciones))
                            vueltas += 1
                            self.assertLess(vueltas, 100)
                        while bj.debe_pedir_crupier(juego):
                            bj.dar_carta_crupier(juego)
                    bj.liquidar_ronda(juego)
                    self.assertTrue(juego['liquidada'])
                    self.assertGreaterEqual(juego['saldo'], 0)
                    self.assertLessEqual(len(juego['manos']), 4)


if __name__ == '__main__':
    unittest.main(verbosity=2)
